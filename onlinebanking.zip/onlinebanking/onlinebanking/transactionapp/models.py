# from curses import ALL_MOUSE_EVENTS
from asyncio import futures
from django.db import models
from onlinebanking.staffapp.models import profile
from django.contrib.auth.models import User
from django.utils import timezone

account_type = [
    ("Savings", "Savings"),
    ("Current", "Current"),
    ("Fixed Deposit", "Fixed Deposit"),
]

# Create your models here.
class Account_table(models.Model):
    account_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    account_balance = models.BigIntegerField(unique=False, null=True)
    account_type = models.CharField(choices=account_type, unique=False, max_length=20)
    account_number = models.CharField(unique=False, max_length=10, default=10101010)
    future_transaction = models.DateTimeField(unique=False, null=True, max_length=20)
    account_pin = models.IntegerField(default=0000, unique=False)


class Transaction_table(models.Model):
    transaction_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    account = models.ForeignKey(Account_table, on_delete=models.CASCADE)
    transaction_type = models.CharField(unique=False, max_length=20)
    transaction_date = models.DateTimeField(default=timezone.now)
    account_number = models.CharField(unique=False, max_length=10)
    sender_account = models.CharField(unique=False, max_length=10, null=True)
    transaction_amount = models.BigIntegerField(unique=False, null=True)
    recepent_number = models.CharField(unique=False, max_length=10, null=True)
    recepent_bank = models.CharField(unique=False, max_length=10, null=True)

class Future_transaction_table(models.Model):
    future_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    owner_account = models.CharField(unique=False, max_length=10)
    recepent_account = models.CharField(unique=False, max_length=10)
    recepent_bank = models.CharField(unique=False, max_length=10)
    transaction_type = models.CharField(unique=False, max_length=20)
    transaction_amount = models.BigIntegerField(unique=False, null=True)
    future_date = models.DateField()
    futures_time = models.TimeField()


    