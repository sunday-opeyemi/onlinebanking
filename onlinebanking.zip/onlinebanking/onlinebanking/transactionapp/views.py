from asyncio import futures
from distutils.dep_util import newer
from django.shortcuts import render, get_object_or_404
from .models import Account_table, Transaction_table, Future_transaction_table
from .forms import Deposit_form, PinAuthentication_form, Change_pin_form, Future_transaction_form
from django.db import models
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import F
from django.http import HttpResponsePermanentRedirect, HttpResponseRedirect
from django.urls import reverse_lazy, reverse
from django.contrib import messages
from numpy import random
import threading, datetime

# Create your views here.
message = ""
acct_number = 0

@login_required
@transaction.atomic
def deposit(request, user_id):
    if request.method == "POST":
        user_form = Deposit_form(request.POST)
        if user_form.is_valid():
            acct_number = user_form.cleaned_data["your_account"]
            amount = user_form.cleaned_data["amount"]
            # update customer's balance in transaction table
            Account_table.objects.filter(user_id=user_id, account_number=acct_number).update(account_balance=F('account_balance') + amount)
            # insert customer's transaction into transaction table for refrence
            userAccount = Account_table.objects.filter(user_id=user_id, account_number=acct_number).values()[0]
            transact = Transaction_table(user_id=user_id, account_id=userAccount.get("account_id"), transaction_type="deposit", account_number=acct_number, transaction_amount=amount)
            transact.save()
            messages.success(request, ('Your deposite '+str(amount)+' was successfully. \n Your total balance is'+ str(userAccount.get("account_balance"))))
        else:
            messages.error(request, ("Your transaction failed"))
        return HttpResponsePermanentRedirect(reverse('deposit', args=(user_id,)))
    else:
        deposit_form = Deposit_form()
        # deposit_form.files["account_number"] = models.forms.ModelChoiceField(queryset=Account_table.objects.filter(user_id=user_id))
        return render(request, 'transactionapp/deposit_form.html', {
        'deposit_form': deposit_form})

@login_required
def pinAuthentication(request, action):
    global acct_number
    if request.method == "POST":
        pin_form = PinAuthentication_form(request.POST)
        if pin_form.is_valid():
            acct_number = pin_form.cleaned_data["your_account"]
            acct_pin = pin_form.cleaned_data["pin"]
        user_account = Account_table.objects.filter(account_number=acct_number, account_pin=acct_pin)
        if user_account:
            return HttpResponsePermanentRedirect(reverse("transaction", args=(action,))) 
        else:
            messages.error(request, ("Your account number and pin does not match please check and try again."))
            return HttpResponsePermanentRedirect(reverse(action, args=(action,))) 
    else:
        pin_form = PinAuthentication_form()
        return render(request, 'transactionapp/pin_auth_form.html', {
        'pin_form': pin_form, })

@transaction.atomic
@login_required
def generalTransaction(request, action):
    global message
    if request.method == "POST":
        user_form = Deposit_form(request.POST)
        if user_form.is_valid():
            benefit_acct = user_form.cleaned_data["beneficiary_account"]
            acct_bank = user_form.cleaned_data["beneficiary_bank"]
            bill_type = user_form.cleaned_data["bill_type"]
            amount = user_form.cleaned_data["amount"]
            benefit_number = user_form.cleaned_data["beneficiary_number"]
            # check which field was filled between benefit account and benefit number in the form.
            if benefit_acct:
                benefit_num = benefit_acct
            else:
                benefit_num = benefit_number
            account_balance = Account_table.objects.filter(user_id=request.user.id, account_number=acct_number).values()[0]
            if account_balance.get("account_balance") > amount:
                if action == "withdraw":
                    # update customer's balance in transaction table
                    Account_table.objects.filter(user_id=request.user.id, account_number=acct_number).update(account_balance=F('account_balance') - amount)

                elif action == "pay_bill":
                    Account_table.objects.filter(user_id=request.user.id, account_number=acct_number).update(account_balance=F('account_balance') - amount)

                    Account_table.objects.filter(account_number=benefit_acct).update(account_balance=F('account_balance') + amount)

                    # generate a dummy number for bill payment
                    bill_number = "22"+str(random.randint(00000000, 99999999))
                    message = "Your "+ bill_type +" transaction code is"+ str(bill_number) +"."

                elif action == "transfer":
                    Account_table.objects.filter(user_id=request.user.id, account_number=acct_number).update(account_balance=F('account_balance') - amount)

                    Account_table.objects.filter(account_number=benefit_acct).update(account_balance=F('account_balance') + amount)

                elif action == "recharge":
                    Account_table.objects.filter(user_id=request.user.id, account_number=acct_number).update(account_balance=F('account_balance') - amount)
                    message = "Your recharge of"+ str(amount) +" was successful."

                else:
                    messages.error(request, ("This transaction is not available for now."))
                    return HttpResponsePermanentRedirect(reverse(action, args=(action,)))
            else:
                messages.error(request, ("Insufficient balance"))
                return HttpResponsePermanentRedirect(reverse(action, args=(action,)))

            # insert customer's transaction into transaction table for refrence
            userAccount = Account_table.objects.filter(user_id=request.user.id, account_number=acct_number).values()[0]
            transact = Transaction_table(transaction_type=action, account_number=acct_number, recepent_number=benefit_num, recepent_bank=acct_bank, account_id=userAccount.get("account_id"), user_id=request.user.id, transaction_amount=amount)
            recepent = Transaction_table(transaction_type=action, account_number=benefit_num, sender_account=acct_number, recepent_bank=acct_bank, account_id=userAccount.get("account_id"), user_id=request.user.id, transaction_amount=amount)
            transact.save()
            recepent.save()
            messages.success(request, ('Your transaction '+str(amount)+' was successfully. Your total balance is'+ str(userAccount.get("account_balance")) +' '+message))
        else:
            messages.error(request, ("Your transaction failed"))
        return HttpResponsePermanentRedirect(reverse(action, args=(action,)))
    else:
        deposit_form = Deposit_form()
        return render(request, 'transactionapp/deposit_form.html', {
        'deposit_form': deposit_form, 'action':action, 'account_num':acct_number})

@login_required
def changePin(request, account_num):
    if request.method == "POST":
        pin_form = Change_pin_form(request.POST)
        if pin_form.is_valid():
            oldPin = pin_form.cleaned_data["oldPin"]
            newPin = pin_form.cleaned_data["newPin"]
            confirmPin = pin_form.cleaned_data["newPin2"]

        user_account = Account_table.objects.filter(account_number=account_num, account_pin=oldPin)
        if user_account and newPin == confirmPin:
            Account_table.objects.filter(user_id=request.user.id, account_number=account_num).update(account_pin=newPin)
            messages.success(request, ("Your account number pin update was successful."))
            return HttpResponsePermanentRedirect(reverse("display_account", args=(request.user.id,)))
        else:
            messages.error(request, ("Your account number and pin does not match please check and try again."))
            return HttpResponsePermanentRedirect(reverse("display_account", args=(request.user.id,))) 
    else:
        pin_form = Change_pin_form()
        return render(request, 'transactionapp/change_pin_form.html', {
        'pin_form': pin_form})

login_required
def displayAccount(request, user_id):
    user_account = Account_table.objects.all().filter(user_id=user_id)
    return render(request, 'transactionapp/show_accounts.html', {
        'user_account': user_account})

login_required
def accountBalance(request, account_num):
    user_account = Account_table.objects.only("account_balance").filter(account_number=account_num)
    messages.success(request, ("Your account balancd is "+str(user_account.values()[0].get("account_balance"))))
    return render(request, 'transactionapp/show_accounts.html', {
        'user_account': user_account})

login_required
def accountStatement(request, account_num):
    user_transaction = Transaction_table.objects.all().filter(account_number=account_num)
    return render(request, 'transactionapp/account_statement.html', {
        'user_transact': user_transaction})

@login_required
def futureTransaction(request, account_num):
    if request.method == "POST":
        future_form = Future_transaction_form(request.POST)
        if future_form.is_valid():
            benefit_acct = future_form.cleaned_data["beneficiary_account"]
            acct_bank = future_form.cleaned_data["beneficiary_bank"]
            bill_type = future_form.cleaned_data["bill_type"]
            amount = future_form.cleaned_data["amount"]
            fdate = future_form.cleaned_data["future_date"]
            ftime = future_form.cleaned_data["future_time"]

            future_trans = Future_transaction_table(owner_account=account_num, recepent_account=benefit_acct, recepent_bank=acct_bank, transaction_type=bill_type, transaction_amount=amount, future_date=fdate, futures_time=ftime, user_id=request.user.id)
            future_trans.save()
            messages.success(request, ("Your future transaction for "+str(account_num) +" account was set successfully."))
            return HttpResponsePermanentRedirect(reverse("display_account", args=(request.user.id,)))

    else:
        future_form = Future_transaction_form()
        return render(request, 'transactionapp/future_transact_form.html', {
        'future_form': future_form, 'account_num':account_num})


# @transaction.atomic
def startFutureTransaction():
    while True:
        tim = datetime.datetime.now()   
        today_date = tim.date()
        today_time = str(tim.strftime("%H"))+":"+str(tim.strftime("%M"))+":"+str(tim.strftime("%S"))
        all_account = Future_transaction_table.objects.all().values()
        for key in all_account:
            if key["future_date"] == today_date and str(key["futures_time"]) == today_time:
                account_balance = Account_table.objects.filter(user_id=key["user_id"], account_number=key["owner_account"]).values()[0]

                Future_transaction_table.objects.filter(user_id=key["user_id"], owner_account=key["owner_account"]).update(future_date=datetime.datetime(tim.year, tim.month+1, 25))

                if account_balance.get("account_balance") > key["transaction_amount"]:
                    Account_table.objects.filter(user_id=key["user_id"], account_number=key["owner_account"]).update(account_balance=F('account_balance') - key["transaction_amount"])

                    Account_table.objects.filter(account_number=key["recepent_account"]).update(account_balance=F('account_balance') + key["transaction_amount"])

                    # insert customer's transaction into transaction table for refrence
                    userAccount = Account_table.objects.filter(user_id=key["user_id"], account_number=key["owner_account"]).values().last()

                    transact = Transaction_table(transaction_type="Future "+key["transaction_type"], account_number=key["owner_account"], recepent_number=key["recepent_account"], recepent_bank=key["recepent_bank"], account_id=userAccount.get("account_id"), user_id=key["user_id"], transaction_amount=key["transaction_amount"])

                    recepent = Transaction_table(transaction_type="Future "+key["transaction_type"], account_number=key["recepent_account"], sender_account=key["owner_account"], recepent_bank="FSB", account_id=userAccount.get("account_id"), user_id=key["user_id"], transaction_amount=key["transaction_amount"])
                    transact.save()
                    recepent.save()
                    print("Future transaction was done successfully")

transaction_thread = threading.Thread(target=startFutureTransaction, name='trans_thread', daemon=True)
transaction_thread.start()