from attr import fields
from django import forms
from matplotlib import widgets
from numpy import require
from .models import Account_table

class GeneralParam():
    def get_account(self):
        account_list = [("", "------"),]
        account_num = Account_table.objects.all().values()
        for account in account_num:
            account_list.append((account['account_number'], account['account_number']))
        return account_list
    bank_name = [
        ("", "--------"),
        ("FBN", "FBN"),
        ("FCMB", "FCMB"),
        ("GTB", "GTB"),
        ("UBA", "UBA")
    ]
    bill_type2 = [
        ("", "-------"),
        ("PHCN", "PHCN"),
        ("GOTV", "GOTV"),
        ("DSTV", "DSTV"),
    ]
    mobile_network2 = [
        ("", "-------"),
        ("MTN", "MTN"),
        ("GLO", "GLO"),
        ("AIRTEL", "AIRTEL"),
        ("ETISALAT", "ETISALAT"),
    ]

class Deposit_form(forms.Form):
    param = GeneralParam()
    your_account = forms.ChoiceField(choices=param.get_account(), label="Your Account number", required=False)
    beneficiary_account = forms.ChoiceField(choices=param.get_account(), label="Beneficiary account number", required=False)
    beneficiary_bank = forms.ChoiceField(choices=param.bank_name, label="", required=False)
    bill_type = forms.ChoiceField(choices=param.bill_type2, label="Type of bill", required=False)
    amount = forms.IntegerField(widget=forms.TextInput(
        attrs={'placeholder': 'Amount'}), label="")
    beneficiary_number = forms.CharField(widget=forms.NumberInput(
        attrs={'placeholder': 'Beneficiary number'}), label="", required=False)
    mobile_network = forms.ChoiceField(choices=param.mobile_network2, label="Your mobile network", required=False)


class PinAuthentication_form(forms.Form):
    param = GeneralParam()
    your_account = forms.ChoiceField(choices=param.get_account(), label="Your account number")
    pin = forms.IntegerField(widget=forms.TextInput(
        attrs={'placeholder': 'Enter your pin'}), label="")


class Change_pin_form(forms.Form): 
    oldPin = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Enter your old pin'}), label="")
    newPin = forms.CharField(widget=forms.PasswordInput(
        attrs={'placeholder': 'Enter your new pin'}), label="")
    newPin2 = forms.CharField(widget=forms.TextInput(
        attrs={'placeholder': 'Enter your confirm pin'}), label="")

class Future_transaction_form(forms.Form):
    bill_type2 = [
        ("", "-------"),
        ("SALARY", "SALARY"),
        ("PHCN", "PHCN"),
        ("GOTV", "GOTV"),
        ("DSTV", "DSTV"),
    ]
    param = GeneralParam()
    
    beneficiary_account = forms.ChoiceField(choices=param.get_account(), label="Beneficiary account number", required=False)
    beneficiary_bank = forms.ChoiceField(choices=param.bank_name, label="", required=False)
    bill_type = forms.ChoiceField(choices=bill_type2, label="Type of bill", required=False)
    amount = forms.IntegerField(widget=forms.TextInput(
        attrs={'placeholder': 'Amount'}), label="")
    future_date = forms.DateField(widget=forms.NumberInput(attrs={'type': 'date'}))
    future_time = forms.TimeField(widget=forms.NumberInput(attrs={'type': 'time'}))
